//Have to include header file to use any of its functions.
#include "GameStructure.h"

//Empty class just to show that all the other files really fall back on this one.
void Gamestructure::Help()
{
}